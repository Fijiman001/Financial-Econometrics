
########################################################################################################################
# Financial Econometrics

# Tatiana Sorokina (M2 MED), Alexander Köhler (M2 EGR), Cerstin Berner (M2 EEE)

# 'Bonus' Homework - April 2025

########################################################################################################################

library(quantmod)
library(tidyquant)
library(dplyr)

########################################################################################################################

set.seed(123)

# Set Up

# Time Increments
T <- 1                
n <- 1000             
dt <- T / n         
time_grid <- seq(0, T, length.out = n + 1)

# Plausible starting value for the volatility, e.g. average volatility of a stock
aapl <- tq_get("AAPL", from = "2010-01-01", to = "2024-12-31")
head(aapl)

aapl <- aapl %>% mutate(log_return = log(close) - log(lag(close))) %>% filter(!is.na(log_return))

# initial volatility
sigma_0 <- var(aapl$log_return)
mu <- 0.01

# Brownian motion --> same one for returns and volatility (based on notation)
dW <- rnorm(n, mean = 0, sd = sqrt(dt))
W <- c(0, cumsum(dW))

# Log starting price
X_0 <- aapl$log_return[6] # take a relatively high starting value to ensure stability


# Volatility model based on heston
kappa <- 5 / 252
alpha <- 0.04 / 252
gamma <- 0.5 / 252

# X =  mu*dt + sigma_0*dW, thus:

X <- numeric(n + 1)
sigma <- numeric(n + 1)

X[1] <- X_0
sigma[1] <- sqrt(sigma_0)

for (i in 2:(n + 1)) {
  
  # Heston variance process
  sigma[i]<- sigma[i-1] + kappa * (alpha - sigma[i-1]) * dt + gamma * sigma[i - 1] * dW[i - 1]
  
  # Update X_t
  X[i] <- X[i - 1] + mu * dt + sigma[i - 1] * dW[i - 1]
}

print(X)
print(sigma)
print(sigma_0)

## Introduce noise:

# Noise levels
E_list <- list(0.001,0.01,0.1)

# intergal for inside
sigma_sq <- sigma^2
int_sigma_sq <- sum(sigma_sq[-(n + 1)]) * dt

# Compute noise variance levels V_epsilon for each e^2
E_list <- c(0.001, 0.01, 0.1)
V_e <- sapply(E_list, function(e2) e2 * sqrt(T * int_sigma_sq))

# see here that the variance of the error term increases with the noise
V_e_results <- round(print(V_e), digits = 5)

# the three nuisance models:
eps1 <- rnorm(length(X), mean = 0, sd = sqrt(V_e[1]))
Y1 <- X + eps1

eps2 <- rnorm(length(X), mean = 0, sd = sqrt(V_e[2]))
Y2 <- X + eps2

eps3 <- rnorm(length(X), mean = 0, sd = sqrt(V_e[3]))
Y3 <- X + eps3

data <- as.data.frame(cbind(X,Y1,Y2,Y3,eps1,eps2,eps3,sigma))

########################################################################################################################
# Model Comparison across Noise Levels
########################################################################################################################

# Naive Average Estimator

library(highfrequency)
library(xts)

# create ffake time stemps
timestamps <- seq.POSIXt(from = as.POSIXct("2025-01-01 09:30:00"), by = "1 sec", length.out = n + 1)

# to xts
Y1_xts <- xts(data$Y1, order.by = timestamps)
Y2_xts <- xts(data$Y2, order.by = timestamps)
Y3_xts <- xts(data$Y3, order.by = timestamps)

# Realized Variance (naive)
RV_Y1 <- rRVar(Y1_xts)
RV_Y2 <- rRVar(Y2_xts)
RV_Y3 <- rRVar(Y3_xts)

# True Integrated Variance as Comparison
int_sigma_sq

comparison_df_naive <- data.frame(
  Noise_Level = c("Low (0.001)", "Medium (0.01)", "High (0.1)"),
  Realized_Variance = c(RV_Y1, RV_Y2, RV_Y3),
  True_Integrated_Variance = int_sigma_sq,
  Difference = c(RV_Y1, RV_Y2, RV_Y3) - int_sigma_sq
)

comparison_df_naive

# Noise_Level Realized_Variance True_Integrated_Variance Difference
# 1   Low (0.001)        0.05995342             0.0003030085 0.05965041
# 2 Medium (0.01)        0.22278995             0.0003030085 0.22248694
# 3    High (0.1)        1.78598411             0.0003030085 1.78568110

########################################################################################################################

# Two Scales Estimator

install.packages("RTAQ")
library(RTAQ)

TS_Y1 <- rAVGCov(Y1_xts)
TS_Y2 <- rAVGCov(Y2_xts)
TS_Y3 <- rAVGCov(Y3_xts)

comparison_df_two_scales <- data.frame(
  Noise_Level = c("Low (0.001)", "Medium (0.01)", "High (0.1)"),
  Realized_Variance = c(TS_Y1, TS_Y2, TS_Y3),
  True_Integrated_Variance = int_sigma_sq,
  Difference = c(TS_Y1, TS_Y2, TS_Y3) - int_sigma_sq
)

comparison_df_two_scales

#Noise_Level Realized_Variance True_Integrated_Variance Difference
#1   Low (0.001)          7.021695             0.0003030085   7.021392
#2 Medium (0.01)          9.504139             0.0003030085   9.503836
#3    High (0.1)         10.958137             0.0003030085  10.957834

########################################################################################################################



# Conclusion:

# Looking at the two model comparisons, it is easily notable that both the "naive" averaging estimator
# as well as the a bit more advanced two scales estimator cannot estimate the integrated variance well. 
# Noteworthy, the large difference between estimates and true parameter is likely the result
# of a miss-specification, nevertheless, one can still see how the level of noise in the returns increases
# the finite sample bias. Noteworthy, the difference in estimates and true parameter is highest for the
# Two Scales model which reports estimates nearly 5 times the Averaging estimator.




